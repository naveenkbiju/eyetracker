Optimize webpage design using eye tracking insights


What is Eye Tracking?
Eye tracking is the process of detecting and analysing eitherthe point of gaze or the motion of an eye relative to the head


'Eye-tracking’ software can give to help design a website.
Identify your site visitors are looking and for how long are theylooking. 
How the size and placement of various page items are affectingtheir attention.
What parts of the user interface do they miss

This is a python file which is used to calibrate gaze tracking. Provided 9 dots in a window. When a person looks to each point and click it for about 5 times with proper eye detection dots colour changes. If eye is not detected properly there comes an warning message box which reminds that eyes are not detected. After this process is done, we get some values regarding the screen positions of each dots and athe eye positions, such as right eye as well as left eyes. This values is then taken to the process of linear regression which is used to predict where my eyes are looking which may be near each dot when clicking them.

There may be some drawbacks in detecting eyes when the lighting is poor or when head moves etc. It can be resolved by using an external hardware.

This project is done by the four of us of S5 CSE-B:
1. Marvel Varghese - 17
2. Kevin Paul K - 9
3. Naveen K Biju - 36
4. Lakshmi Harish Kumar - 14

